package com.example.file_storage_aws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileStorageAwsApplicationTests {

	@Test
	void contextLoads() {
	}

}
